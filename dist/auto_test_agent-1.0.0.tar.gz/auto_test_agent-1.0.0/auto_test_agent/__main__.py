#!/usr/bin/env python3
"""CLI entry point — ``python -m auto_test_agent chat``.

After ``pip install -e .``, you can run::

    python -m auto_test_agent chat           # interactive REPL
    python -m auto_test_agent run --goal ...  # one-shot pipeline
    python -m auto_test_agent list-models     # show model presets
    sdk-test-agent --goal "generate tests"    # entry-point script
"""

from __future__ import annotations

import os
import sys

# Ensure the project root is on ``sys.path`` so the flat modules
# (agent.py, __main__.py, cli.py, model_config.yaml, …) are importable
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)


def _run_cli() -> None:
    """Import the project-root CLI module and dispatch."""
    # Must use importlib — ``from __main__ import main`` would import *this*
    # module (which *is* __main__ at runtime), not the project-root __main__.py.
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        "_root_cli",
        os.path.join(_project_root, "__main__.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    mod.main()


_cli_main = _run_cli

if __name__ == "__main__":
    _run_cli()

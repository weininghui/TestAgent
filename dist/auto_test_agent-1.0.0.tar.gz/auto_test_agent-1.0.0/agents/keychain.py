"""In-memory API key store — set keys interactively, no env vars needed.

Usage::

    from agents.keychain import set_key, get_key

    set_key("OPENAI_API_KEY", "sk-xxx")   # store in memory
    key = get_key("OPENAI_API_KEY")        # keychain → os.environ

Keys set here are kept **only for the current session** — they are never
written to disk unless the user explicitly asks to save them to ``.env``.
"""

from __future__ import annotations

import os

_keys: dict[str, str] = {}


def set_key(name: str, value: str) -> None:
    """Store an API key in memory for the current session.

    Also sets the corresponding ``os.environ`` variable so that any
    downstream library (e.g. ``openai``) can find it without changes.
    """
    _keys[name] = value
    os.environ[name] = value


def get_key(name: str) -> str | None:
    """Return an API key, checking the keychain first, then ``os.environ``.

    Returns ``None`` if no key is found in either location.
    """
    if name in _keys:
        return _keys[name]
    return os.environ.get(name)


def has_key(name: str) -> bool:
    """Return ``True`` if a key is available (keychain or env var)."""
    return get_key(name) is not None and len(get_key(name)) > 0


def list_keys() -> list[str]:
    """Return the names of all keys currently stored in the keychain."""
    return sorted(_keys.keys())


def clear_keys() -> None:
    """Remove all keys from the in-memory store (session end / reset)."""
    _keys.clear()
